const express = require('express');
const app = express();
const path = require('path');
const bodyParser = require('body-parser');
const cors = require('cors');
const jwt = require('jsonwebtoken');
const db = require("./models");
const bcrypt = require('bcryptjs');
const JWT_SECRET = 'serttyu876554@%_*$6kllijhgfd'
const appRoute = require("./routes/userConficRouter");

db.sequelize.sync();
const User = db.user;
app.use(bodyParser.json());
app.use('/', express.static(path.join(__dirname, 'static')));

app.post('/api/login', async (req, res) => {
    const { username, password } = req.body
    const user = await User.findOne({ where: { username: username },attributes:['username','password']});
    // console.log(user);

    if (user === null) {
        console.log('Invalid User/password');
        return res.json({ status: 'error', error: "Invalid Username or password !" })
    }

    if (password === user.password) {
        const token = jwt.sign({
            id: user.id,
            username: user.username
        }, JWT_SECRET)
        return res.json({ status: 'ok', data: token })
    }
    res.json({ status: 'ok', data: "Success" });
})

app.post('/api/register', async (req, res) => {
    // console.log(req.body);
    // const { username, password: plainText } = req.body
    const { username, password } = req.body
    if (!username || typeof username !== 'string') {
        return res.json({ status: "error", error: 'Invalid Username' });
    }
    if (!password || typeof password !== 'string') {
        return res.json({ status: "error", error: 'Invalid password' });
    }
    if (password.length < 5) {
        return res.json({
            status: 'error',
            error: 'Password too small,should be atleast 6 character'
        })
    }
    // const password = await bcrypt.hash(plainText, 10)
    try {
        const response = await User.create({
            username,
            password
        });

        console.log('User created successfully', response);

    } catch (e) {
        // console.log(JSON.stringify(e));
        return res.json({ status: 'error' })
    }

    res.json({ status: 'ok' });
})
//User CRUD operation
app.use("/api", appRoute);

const PORT = process.env.PORT || 9999;
app.listen(PORT, (req, res) => {
    console.log(`Server is running on port ${PORT}`);
})