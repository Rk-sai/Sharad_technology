'use strict';
const UserService = require('../services/userservice');
var UserController = {
    //Api for get all user
    getAllUser:async(req,res,next)=>{
        try{
            var Result= await UserService.getAllUsers();
            return res.send({ "response":Result, success: true, message: "Fatched successfully" });
        }catch(err){
         next(err);
        }
    },
    //Api for create user
    CreateUser:async(req,res,next)=>{
        try{
            var Result= await UserService.createUser(req.body);
            return res.send({ "response":Result, success: true, message: "Saved successfully" });
        }catch(err){
         next(err);
        }
    },
    //Api for update user
    UpdateUser:async(req,res,next)=>{
        try{
            var Result= await UserService.updateUser(req.body);
            return res.send({ "response":Result, success: true, message: "Updated successfully" });
        }catch(err){
         next(err);
        }
    },
    //Api for delete user
    DeleteUser:async(req,res,next)=>{
        try{
            var Result= await UserService.deleteUser(req.param.id);
            return res.send({ "response":Result, success: true, message: "Deleted successfully" });
        }catch(err){
         next(err);
        }
    }
};
module.exports = UserController;