const Sequelize = require('sequelize');
var models = require('../models');
var User=models.user;

var UserService = {
    //function for get all user
    getAllUsers:async()=>{
      var Result= await User.findAll({
        attributes:["username"],
        raw: true,
      });
      return Result;
    },
 //function for create user
    createUser:async(data)=>{
    var FinsUser=await findOne({
        attributes:["id"],
        where:{
            id:data.id
        },
        raw:true
    })
    if(FinsUser != null){
     var Result=await User.create(data);
    }
     return Result;
    },
 //function for update user
    updateUser:async(data)=>{
        var Result=await User.update({data,
            where:{
                id:data.id
            },
            raw:true
        });
     return Result; 
    },
 //function for delete user
    deleteUser:async(data)=>{
        var Result=await User.destroy({
            where:{
                id:data.id 
            }
        });
        return Result
    }
};
module.exports = UserService;