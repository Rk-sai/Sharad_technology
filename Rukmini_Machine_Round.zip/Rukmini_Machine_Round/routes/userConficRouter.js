'use strict';
const express = require("express");
const route = express.Router();
const appController = require("../controller/usercontroller");

route.get("/getuser", appController.getAllUser);
route.post("/createuser", appController.CreateUser);
route.put("/updateuser/:id",  appController.UpdateUser);
route.delete("/deleteuser/:id",  appController.DeleteUser);

module.exports = route;